# RichWebApplicationLab1
2nd Lab, but the first lab that has to be demoed for the Module: Rich Web Applications.
